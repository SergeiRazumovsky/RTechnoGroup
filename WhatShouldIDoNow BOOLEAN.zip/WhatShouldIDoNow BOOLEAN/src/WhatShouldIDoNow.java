public class WhatShouldIDoNow {
    public static void main(String[] args) {
        float timenow = 22.30f;
        int temperaturenow = 23;
        boolean late = timenow >= 22.00;
        boolean warm = temperaturenow >= 20;


        if (late) {
            System.out.println("Иди спать");
        }
        if (!late && warm) {
            System.out.println("Иди гулять");
        }
        if (!late && !warm) {
            System.out.println("Почитай книгу дома");
        }
    }
}