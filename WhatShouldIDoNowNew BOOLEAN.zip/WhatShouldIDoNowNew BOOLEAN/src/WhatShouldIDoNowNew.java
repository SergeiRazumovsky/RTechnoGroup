public class WhatShouldIDoNowNew {
    public static void main(String[] args) {
        float timenow = 9.30f;
        boolean isGoodWeather = false;
        boolean late = timenow >= 23 || timenow <= 5;
//__________________________________________________________________

        if (late) {
            System.out.println("Иди спать");
        }
        if (!late && isGoodWeather) {
            System.out.println("Иди гулять");
        }
        if (!late && !isGoodWeather) {
            System.out.println("Почитай книгу дома");
        }
    }
}