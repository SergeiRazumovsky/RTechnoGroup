import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BuyingFood {
    public static void main(String[] args) {
        int TheAmountOfMoneyInTheWallet = 550;

        System.out.println("Добрый День!)))");
        DateFormat format = new SimpleDateFormat( "Сегодня dd/MMMM/y/EEEE hh:mm a");
        Date date = new Date();
        System.out.println (format.format(date));
        System.out.println("Ваш баланс состовляет " + TheAmountOfMoneyInTheWallet + " рублей");

        if (TheAmountOfMoneyInTheWallet >= 400)
        {
            System.out.println("Вы можете купить полезную пищу на обед, Вы состоятельный человек!!!");
        }
        else if (TheAmountOfMoneyInTheWallet >= 300)
        {
            System.out.println("Вы можете купить нормальную пищу на обед и можете считать себя средним классом!");
        }
        else if (TheAmountOfMoneyInTheWallet >= 200)
        {
            System.out.println("Вы можете купить терпимую пищу на обед, но будте осторожны с этой едой!");
        }
        else if (TheAmountOfMoneyInTheWallet >= 100)
            {
                System.out.println("Вы можете купить ужазную пищу на обед, которой скорее всего отравитесь!");
        }
        else
        {
            System.out.println("Кроме жевачки Вы не можете себе ни чего позволить!!!");
        }
    }
}
