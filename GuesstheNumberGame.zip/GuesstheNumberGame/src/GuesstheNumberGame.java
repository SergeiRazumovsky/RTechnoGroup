import java.util.Random;
import java.util.Scanner;
public class GuesstheNumberGame {
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scan = new Scanner(System.in);  //осущетвляет захват информации из консоли
        int computer = rand.nextInt(10);   //Число, загаданное компьютером
        int user = 2;                     // Число, которое вводит пользователь
        while (true) {      //неравенство. Выполняет действия в своих фигурных скобках пока условие в круглых скобках верно
            System.out.println("Попытайтесь угадать число");
            user = scan.nextInt();
            if (computer == user) {
                System.out.println("Вы угадали! Загаданное число было " + computer);
                computer = rand.nextInt(10);
            } else if (computer > user) {
                System.out.println("Вы продули, загаданное число было больше чем Ваше, а именно " + computer);
            }
            else if (computer < user) {
                System.out.println("Вы продули, загаданное число было меньше чем Ваше, а именно " + computer);
            }
        }
    }}
