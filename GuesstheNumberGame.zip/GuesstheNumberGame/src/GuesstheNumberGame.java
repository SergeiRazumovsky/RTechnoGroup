import java.util.Random;
import java.util.Scanner;

public class GuesstheNumberGame {
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scan = new Scanner(System.in); //осущетвляет захват информации из консоли

        int computer = rand.nextInt(10); //Число, загаданное компьютером
        int user = 2;           // Число, которое ввод// ит пользователь
        int money = 200;        // Деньги
        int difficult = 0;      // переменная уровня сложности
        String temp = " ";
        int temp2 = 0;          // Вспомогательная переменная
        int bank = money;       // Хранить деньги, введённые в игру

        while (difficult == 0) {

            System.out.println("Пожалуйста, выберите сложность ");
            System.out.println("Возможные варианты: Легкий, Средний, Сложный ");
            temp = scan.nextLine();
            if (temp.equalsIgnoreCase("легкий")) { //сравниваем текст из переменной с данным
                difficult = 1;
            }
            else if (temp.equalsIgnoreCase("средний")) { //сравниваем текст из переменной с данным
                difficult = 2;
            }
            else if (temp.equalsIgnoreCase("сложный")) { //сравниваем текст из переменной с данным
                difficult = 3;
            }
            else {
                System.out.println("Некорректно, попробуйте заново");
            }
        }

        while (true) { //неравенство. Выполняет действия в своих фигурных скобках пока условие в круглых скобках верно

            if (money >= 50 * difficult) {
                System.out.println("Попытайтесь угадать число");
                user = scan.nextInt(); // пользователь вводит число, которое сравнивается с загаданным

                if (computer == user) {
                    System.out.println("Вы угадали!");
                    computer = rand.nextInt(10);
                    if (difficult == 1) {
                        money += 50;
                    }
                    else if (difficult == 2) {
                        money += 100;
                    }
                    else if (difficult == 3) {
                        money += 150;
                    }
                }
                else {
                    System.out.println("Вы проиграли, загаданное число было " + computer);
                    if (difficult == 1) {
                        money -= 50;
                    }
                    else if (difficult == 2) {
                        money -= 100;
                    }
                    else if (difficult == 3) {
                        money -= 150;
                    }
                }
                System.out.println("Ваш баланс " + money + " рублей");
                System.out.println("Продолжаем игру: Да / Нет?");
                temp = scan.next();
                if (temp.equalsIgnoreCase("да")) { //сравниваем текст из переменной с данным
                    System.out.println("Отлично! Продолжаем! ");
                }
                else if (temp.equalsIgnoreCase("нет")) { //сравниваем текст из переменной с данным
                    System.out.println("Очень жаль! До новых встреч!!!");
                    System.out.println("Всего Вы положили " + bank + " рублей");
                    if ((bank - money) > 0) {
                        System.out.println("А проиграли Вы " + (bank - money) + " рублей");   //+ проиграли, а - выйграли
                    }
                    else if ((bank - money) < 0) {
                        System.out.println("А выйграли Вы " + (-(bank - money)) + " рублей");   //+ проиграли, а - выйграли
                    }
                    else {
                        System.out.println("Вы отались при своих!");
                    }
                    break; // Выходит из последнего вызванного цикла (игнорируя оставшиеся команды в цикле)
                }
            }

            if (money < 50 * difficult) {
                System.out.println("У Вас кончились деньги");
                System.out.println("Желаете продолжить игру: Да / Нет ?");
                temp = scan.next();
                if (temp.equalsIgnoreCase("да")) { //сравниваем текст из переменной с данным
                    System.out.println("Отлично! В этот раз Вам обязательно повезет!!! ");
                    System.out.print("Сколько Вы хотите положить денег? ");
                    temp2 = scan.nextInt();
                    money += temp2;
                    bank += temp2;
                    System.out.println("Ваш баланс " + money + " рублей");
                }
                else if (temp.equalsIgnoreCase("нет")) { //сравниваем текст из переменной с данным
                    System.out.println("Очень жаль! До новых встреч!!!");
                    System.out.println("Всего Вы положили " + bank + " рублей");
                    if ((bank - money) > 0) {
                        System.out.println("А проиграли Вы " + (bank - money) + " рублей");   //+ проиграли, а - выйграли
                    }
                    else if ((bank - money) < 0) {
                        System.out.println("А выйграли Вы " + (-(bank - money)) + " рублей");   //+ проиграли, а - выйграли
                    }
                    else {
                        System.out.println("Вы отались при своих!");
                    }
                    break; // Выходит из последнего вызванного цикла (игнорируя оставшиеся команды в цикле)
                }
            }
        }
    }
}
