import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class PlaneTicketsWhile {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int mass[][] = new int[16][16];
        int mass2[][] = new int[11][11];
        int choice = 0;
        int money = 0;
        int seatnumber =0;
        DateFormat format = new SimpleDateFormat("В HH:mm dd/MMMM/y/EEEE");

        for (int y = 0; y < mass.length; y++)
        {
            for (int x = 0; x < mass.length; x++)
            {
                mass[y][x] = x+1;
            }
        }
        for (int y = 0; y < mass2.length; y++)
        {
            for (int x = 0; x < mass2.length; x++)
            {
                mass2[y][x] = x+1;
            }
        }
        System.out.println("Уважаемый Октавиан!");
        System.out.println("Мы рады приветсвовать Вас, как будующего пассажира авиакомпании Skillbox Airlines");
        System.out.println("Для более комфортабельного перелёта мы рады предложить Вам места в САЛОНЕ ПЕРВОГО КЛАССА, а также в САЛОНЕ БИЗНЕСС-КЛАССА");
        System.out.println("Какой уровень комфорта Вы выберете?");
        System.out.println("Нажмите 1 - если выбираете ПЕРВЫЙ КЛАСС");
        System.out.println("Нажмите 2 - если выбираете БИЗНЕСС-КЛАСС");
        choice = scan.nextInt();
        if (choice == 1)
        {
            System.out.println("Отличный выбор! \nПЕРВЫЙ КЛАСС нашей Компании самый лучший на рынке! \nПерейдём к подбору места в салоне.");
            System.out.println("Просим Вас ознакомиться с наличием свободных мест.");
            System.out.println(" ");
            System.out.println("САЛОН ПЕРВОГО КЛАССА");
            for (int y = 0; y < mass.length; y++)
            {
                System.out.println();
                for (int x = 0; x < mass.length; x++)
                {
                    System.out.print(mass[y][x] + "\t");
                }
            }
            System.out.println(" ");
            System.out.println(" ");
            System.out.println("Теперь о стоимости билетов");
            System.out.println(" ");
            int checkingmoney = 220;
            while (checkingmoney <= 235)
            {
                System.out.print("При наличии у Вас " + checkingmoney + " тысяч рублей Вы можете: ");
                if (checkingmoney >= 220 && checkingmoney <= 224)
                {
                    System.out.println("приобрести билеты на места с 1 по 5");
                }
                if (checkingmoney >= 225 && checkingmoney <= 229)
                {
                    System.out.println("приобрести билеты на места с 6 по 10");
                }
                else if (checkingmoney >= 230)
                {
                    System.out.println("приобрести билеты на места с 11 по 16");
                }
                checkingmoney++;
            }
            System.out.println("При наличии у Вас суммы менее 220 тысяч рублей Вы можете рассмотреть БИЗНЕСС-КЛАСС");
            System.out.println("Подумайте на какое место Вы бы хотели приобрести билет");
            seatnumber = scan.nextInt();
            if (seatnumber >= 1 && seatnumber <= 5)
            {
                System.out.println("Введите необходимую сумму в размере от 220 до 224 тысяч рублей в формате 220, 221, 222 и т.д.");
                money = scan.nextInt();
                if (money >= 220)
                {
                    System.out.println("Уважаемый Октавиан! Оплата прошла успешно. Ваше место № " + seatnumber + ". Электронные билеты направлены на Ваш e-mail.\nБлагодарим за то, что Вы выбрали авиакомпанию Skillbox Airlines!");
                }
            }
            if (seatnumber >= 6 && seatnumber <= 10)
            {
                System.out.println("Введите необходимую сумму в размере от 225 до 229 тысяч рублей в формате 225, 226, 227 и т.д.");
                money = scan.nextInt();
                if (money >= 225)
                {
                    System.out.println("Уважаемый Октавиан! Оплата прошла успешно. Ваше место № " + seatnumber + ". Электронные билеты направлены на Ваш e-mail.\nБлагодарим за то, что Вы выбрали авиакомпанию Skillbox Airlines!");
                }
            }
            if (seatnumber >= 11 && seatnumber <= 16)
            {
                System.out.println("Введите необходимую сумму в размере от 230 тысяч рублей в формате 230, 231, 232 и т.д.");
                money = scan.nextInt();
                if (money >= 230)
                {
                    System.out.println("Уважаемый Октавиан! Оплата прошла успешно. Ваше место № " + seatnumber + ". Электронные билеты направлены на Ваш e-mail.\nБлагодарим за то, что Вы выбрали авиакомпанию Skillbox Airlines!");
                }
            }
            System.out.println("Ваш вылет состоится:");
            Date date = new Date();
            System.out.println(format.format(date));
        }
        if (choice == 2)
        {
            System.out.println("Отличный выбор! \nУ БИЗНЕСС-КЛАССА есть свои преимущества! \nПерейдём к подбору места в салоне.");
            System.out.println("Просим Вас ознакомиться с наличием свободных мест.");
            System.out.println(" ");
            System.out.println("САЛОН БИЗНЕСС-КЛАССА");
            for (int y = 0; y < mass2.length; y++)
            {
                System.out.println();
                for (int x = 0; x < mass2.length; x++)
                {
                    System.out.print(mass2[y][x] + "\t");
                }
            }
            System.out.println(" ");
            System.out.println(" ");
            System.out.println("Теперь о стоимости билетов");
            System.out.println(" ");
            int checkingmoney = 200;
            while (checkingmoney <= 210)
            {
                System.out.print("При наличии у Вас " + checkingmoney + " тысяч рублей Вы можете: ");
                if (checkingmoney >= 200 && checkingmoney <= 204)
                {
                    System.out.println("приобрести билеты на места с 1 по 3");
                }
                if (checkingmoney >= 205 && checkingmoney <= 209)
                {
                    System.out.println("приобрести билеты на места с 4 по 7");
                }
                else if (checkingmoney >= 210)
                {
                    System.out.println("приобрести билеты на места с 8 по 11");
                }
                    checkingmoney++;
            }
            System.out.println("При наличии у Вас суммы менее 200 тысяч рублей Вы можете рассматривать только ЭКОНОМ-КЛАСС");
            System.out.println("Подумайте на какое место Вы бы хотели приобрести билет");
            seatnumber = scan.nextInt();
            if (seatnumber >= 1 && seatnumber <= 3)
            {
                System.out.println("Введите необходимую сумму в размере от 200 до 204 тысяч рублей в формате 200, 201, 202 и т.д.");
                money = scan.nextInt();
                if (money >= 200)
                {
                    System.out.println("Уважаемый Октавиан! Оплата прошла успешно. Ваше место № " + seatnumber + ". Электронные билеты направлены на Ваш e-mail.\nБлагодарим за то, что Вы выбрали авиакомпанию Skillbox Airlines!");
                }
            }
            if (seatnumber >= 4 && seatnumber <= 7)
            {
                System.out.println("Введите необходимую сумму в размере от 205 до 209 тысяч рублей в формате 205, 206, 207 и т.д.");
                money = scan.nextInt();
                if (money >= 205)
                {
                    System.out.println("Уважаемый Октавиан! Оплата прошла успешно. Ваше место № " + seatnumber + ". Электронные билеты направлены на Ваш e-mail.\nБлагодарим за то, что Вы выбрали авиакомпанию Skillbox Airlines!");
                }
            }
            if (seatnumber >= 8 && seatnumber <= 11)
            {
                System.out.println("Введите необходимую сумму в размере от 210 тысяч рублей в формате 210, 211, 212 и т.д.");
                money = scan.nextInt();
                if (money >= 210)
                {
                    System.out.println("Уважаемый Октавиан! Оплата прошла успешно. Ваше место № " + seatnumber + ". Электронные билеты направлены на Ваш e-mail.\nБлагодарим за то, что Вы выбрали авиакомпанию Skillbox Airlines!");
                }
            }
            System.out.println("Ваш вылет состоится:");
            Date date = new Date();
            System.out.println(format.format(date));
        }
    }
}
