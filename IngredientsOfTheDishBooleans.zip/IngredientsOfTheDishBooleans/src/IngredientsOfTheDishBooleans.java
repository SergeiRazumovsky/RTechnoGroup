import java.util.Scanner;

public class IngredientsOfTheDishBooleans
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int milkAmount = 0;   // ml
        int powderAmount = 0; // g
        int eggsCount = 0;    // items
        int sugarAmount = 0;  // g
        int oilAmount = 0;    // ml
        int appleCount = 0;

        System.out.println("Enter the ingredients you have");
        System.out.print("milk (ml) = ");
        milkAmount = scan.nextInt();

        System.out.print("powder (g) = ");
        powderAmount = scan.nextInt();

        System.out.print("eggs (items) = ");
        eggsCount = scan.nextInt();

        System.out.print("sugar (g) = ");
        sugarAmount = scan.nextInt();

        System.out.print("oil (ml) = ");
        oilAmount = scan.nextInt();

        System.out.print("apple = ");
        appleCount = scan.nextInt();

        if (powderAmount >= 400 && milkAmount >= 1 && sugarAmount >= 10 && oilAmount >= 30)
        {
            System.out.println("You can cook a Pancakes");
        }
        if (powderAmount >= 300 && milkAmount >= 100 && eggsCount >= 4 && appleCount >= 3)
        {
            System.out.println("You can cook a Apple pie");
        }
        if (powderAmount >= 5 && milkAmount >= 300 && eggsCount >= 5)
        {
            System.out.println("You can cook a Omelette");
        }
        else
        {
            System.out.println("You can't cook anything");
        }
    }
}
