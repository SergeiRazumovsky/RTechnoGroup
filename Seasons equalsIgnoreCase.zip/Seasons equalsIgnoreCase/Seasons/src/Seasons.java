import java.util.Scanner;

public class Seasons {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String choice = " ";
        System.out.println("У какого месяца Вы хотели бы уточнить время года? \nВведите его название");
        choice = scan.next();
        if (choice.equalsIgnoreCase ("Январь"))
        {
            System.out.println("Январь - это первый месяц года. \nВремя года - Зима.");
        }
        else if (choice.equalsIgnoreCase ("Февраль"))
        {
            System.out.println("Февраль - это второй месяц года. \nВремя года - Зима.");
        }
        else if (choice.equalsIgnoreCase ("Март"))
        {
            System.out.println("Март - это третий месяц года. \nВремя года - Весна.");
        }
        else if (choice.equalsIgnoreCase ("Апрель"))
        {
            System.out.println("Апрель - это четвертый месяц года. \nВремя года - Весна.");
        }
        else if (choice.equalsIgnoreCase ("Май"))
        {
            System.out.println("Май - это пятый месяц года. \nВремя года - Весна.");
        }
        else if (choice.equalsIgnoreCase ("Июнь"))
        {
            System.out.println("Июнь - это шестой месяц года. \nВремя года - Лето.");
        }
        else if (choice.equalsIgnoreCase ("Июль"))
        {
            System.out.println("Июль - это седьмой месяц года. \nВремя года - Лето.");
        }
        else if (choice.equalsIgnoreCase ("Август"))
        {
            System.out.println("Август - это восьмой месяц года. \nВремя года - Лето.");
        }
        else if (choice.equalsIgnoreCase ("Сентябрь"))
        {
            System.out.println("Сентябрь - это девятый месяц года. \nВремя года - Осень.");
        }
        else if (choice.equalsIgnoreCase ("Октябрь"))
        {
            System.out.println("Октябрь - это десятый месяц года. \nВремя года - Осень.");
        }
        else if (choice.equalsIgnoreCase ("Ноябрь"))
        {
            System.out.println("Ноябрь - это одинадцатый месяц года. \nВремя года - Зима.");
        }
        else if (choice.equalsIgnoreCase ("Декабрь"))
        {
            System.out.println("Декабрь - это двенадцатый месяц года. \nВремя года - Зима.");
        }
        else
        {
            System.out.println("Такого месяца не существует!");
        }
    }
}
