import java.util.Scanner;

public class SeasonsSwitchCase {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String choice = " ";
        System.out.println("У какого месяца Вы хотели бы уточнить время года? \nВведите его название");
        choice = scan.next();
        switch (choice) // Функция проверяет значение, введеное пользователем
        {
            case "Январь" :  // то же самое, что и if. Если то то, тогда выведи на экран то то
                System.out.println("Январь - это первый месяц года. \nВремя года - Зима.");
                break;
            case "Февраль" :
                System.out.println("Февраль - это второй месяц года. \nВремя года - Зима.");
                break;
            case "Март" :
                System.out.println("Март - это третий месяц года. \nВремя года - Весна.");
                break;
            case "Апрель" :
                System.out.println("Апрель - это четвертый месяц года. \nВремя года - Весна.");
                break;
            case "Май" :
                System.out.println("Май - это пятый месяц года. \nВремя года - Весна.");
                break;
            case "Июнь" :
                System.out.println("Июнь - это шестой месяц года. \nВремя года - Лето.");
                break;
            case "Июль" :
                System.out.println("Июль - это седьмой месяц года. \nВремя года - Лето.");
                break;
            case "Август" :
                System.out.println("Август - это восьмой месяц года. \nВремя года - Лето.");
                break;
            case "Сентябрь" :
                System.out.println("Сентябрь - это девятый месяц года. \nВремя года - Осень.");
                break;
            case "Октябрь" :
                System.out.println("Октябрь - это десятый месяц года. \nВремя года - Осень.");
                break;
            case "Ноябрь" :
                System.out.println("Ноябрь - это одинадцатый месяц года. \nВремя года - Зима.");
                break;
            case "Декабрь" :
                System.out.println("Декабрь - это двенадцатый месяц года. \nВремя года - Зима.");
                break;
            default :
                System.out.println("Такого месяца не существует!");
                break;
        }
    }
}
