public class CycleFor {
    public static void main(String[] args) {
        for (int i = 1000; i > 0; i--) // Изначально i = 1000, от него мы начинаем считать до тех пор пока i > 0. После выполнения блока кода уменьшаем i на 1
        {
            if (i % 3 == 0) // Если остаток от деления на 3 равен 0
            {
                System.out.println(i);  // то мы выводим i на экран
            }
        }
    }
}
