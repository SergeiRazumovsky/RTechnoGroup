import java.util.Scanner;

public class PINcodeAtTheATM {
    public static void main(String[] args) {
        int secretPinCode = 1234;
        int pinCode = -1;
        Scanner scanner = new Scanner(System.in);

        while (pinCode != secretPinCode)
        {
        if (pinCode == -1)
        {
            System.out.println("Введите PIN-code:");
        }
        else
        {
            System.out.println("PIN-code введён неверно. Введите верный PIN-code:");
        }
            pinCode = scanner.nextInt();
        }
            System.out.println("PIN-code введён верно!!!");
    }
}