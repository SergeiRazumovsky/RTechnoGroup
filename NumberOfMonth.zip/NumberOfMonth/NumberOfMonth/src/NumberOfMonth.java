import java.util.Scanner;

public class NumberOfMonth {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int choice = 0;
        System.out.println("What month of the account do you want to withdraw? \"Enter the number\"");
        choice = scan.nextInt();
        if (choice == 1) {
            System.out.println("First month in year - January");
        }
        else if (choice == 2) {
            System.out.println("Second month in year - February");
        }
        else if (choice == 3) {
            System.out.println("Third month in year - March");
        }
        else if (choice == 4) {
            System.out.println("Fourth month in year - April");
        }
        else if (choice == 5) {
            System.out.println("Fifth month in year - May");
        }
        else if (choice == 6) {
            System.out.println("Sixth month in year - June");
        }
        else if (choice == 7) {
            System.out.println("Seventh month in year - July");
        }
        else if (choice == 8) {
            System.out.println("The 8th month in year - August");
        }
        else if (choice == 9) {
            System.out.println("The ninth month in year - September");
        }
        else if (choice == 10) {
            System.out.println("Tenth month in year - October");
        }
        else if (choice == 11) {
            System.out.println("The eleventh month in year - November");
        }
        else if (choice == 12) {
            System.out.println("Twelfth month in year - December");
        }
        else
        {
            System.out.println("Invalid number");
        }
    }
}
