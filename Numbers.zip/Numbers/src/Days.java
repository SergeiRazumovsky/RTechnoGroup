public class Days {
    public static void main(String[] args) {
        int days = 1095;
        int ears = days / 365;
        int months = (days % 365) / 31;
        int leftDays = days - ears * 365 - months * 31;
        System.out.println("Общее количество дней: " + days);
        System.out.println("Количество лет: " + ears);
        System.out.println("Количество месяцев: " + months);
        System.out.println("Количество оставшихся дней: " + leftDays);
    }
}
