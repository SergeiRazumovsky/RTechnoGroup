public class Seconds {
    public static void main(String[] args) {
        int seconds = 259200;
        int days = seconds / 86400;
        int hours = (seconds % 86400) / 1200;
        int minutes = hours / 60;
        int LeftSeconds = seconds - days * 86400 - hours * 1200 - minutes * 60;
        System.out.println("Общее количество дней: " + days);
        System.out.println("Количество часов: " + hours);
        System.out.println("Количество минут: " + minutes);
        System.out.println("Оставшиеся секунды: " + LeftSeconds);
    }
}
