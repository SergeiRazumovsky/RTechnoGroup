
public class Loader
{
    public static void main(String[] args)
    {
        // Мурка будет умирать
        // Вася будет переедать
        // Скиф будет переедать
        // Соломон будет спать
        // Марк будет играть
        //======================================================================

        Cat murka = new Cat();
            System.out.println("Cat Murka weight: " + murka.getWeight());
        while (murka.getWeight() > 1000)
        {
            murka.meow();
            System.out.println("Cat Murka weight: " + murka.getWeight());
            System.out.println("Cat Murka is " + murka.getStatus());
        }
            System.out.println(" ");

        Cat vasya = new Cat();
            System.out.println("Cat Vasya weight: " + vasya.getWeight());
        while (vasya.getWeight() < 9000)
        {
            vasya.eat();
            System.out.println("Cat Vasya weight: " + vasya.getWeight());
            System.out.println("Cat Vasya is " + vasya.getStatus());
        }
            System.out.println(" ");

        Cat skif = new Cat();
            System.out.println("Cat Skif weight: " + skif.getWeight());
        while (skif.getWeight() < 9000)
        {
            skif.eat();
            System.out.println("Cat Skif weight: " + skif.getWeight());
            System.out.println("Cat Skif is " + skif.getStatus());
        }
            System.out.println(" ");

        Cat solomon = new Cat();
            System.out.println("Cat Solomon weight: " + solomon.getWeight());
            solomon.eat();
            System.out.println("Cat Solomon weight: " + solomon.getWeight());
            System.out.println("Cat Solomon is " + solomon.getStatus());
            System.out.println(" ");

        Cat mark = new Cat();
            System.out.println("Cat Mark is " + mark.getStatus());
    }
}