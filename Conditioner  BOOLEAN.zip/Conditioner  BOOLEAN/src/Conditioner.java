public class Conditioner {
    public static void main(String[] args) {
        int temperature = 22;
        int time = 24;
        boolean late = time >= 23;      // boolean - оператор который имеет в себе только два значения - true или false
        boolean hot = temperature > 25;

        if (!hot && late) {            // ! - означает отрицание, && - означает ИЛИ, вместо него можно подставить || - означает И
            System.out.println("Кондиционер выключен");

        }
    }
}
