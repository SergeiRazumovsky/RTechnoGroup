public class StringArray {
    public static void main(String[] args) {
        String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}; // Задаем строчный массив
        String result = "";
        for (int i = 0; i < months.length; i++) // Включаем счетчик
        {
            result += months [i];
        if (i == months.length - 1) // Если у нас последний месяц, то ставим после него точку
        {
            result += ".";
        }
        else
        {
            result += ","; // Если у нас не последний месяц, то ставим после него запятую
        }
        }
            System.out.println(result);
    }
}
