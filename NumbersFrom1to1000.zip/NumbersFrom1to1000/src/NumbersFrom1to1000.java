public class NumbersFrom1to1000 {
    public static void main(String[] args) {
        int i = 1;
        while (i < 1000) {
            System.out.println(i);
            i++;
            // if (i == 5) {  // Используется в случае, если мы хотим прервать выведение чисел в консоль, например, когда i станет равно 5
            // break;
            // }
        }
    }
}
