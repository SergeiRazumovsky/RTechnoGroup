public class Conditioner {
    public static void main(String[] args) {
        int temperature = 21;
        if (temperature > 25) {
            System.out.println("Кондиционер влючен");
        }
        else if (temperature < 22){
            System.out.println("Кондиционер выключен");
        }
        else
            System.out.println("Кондиционер ни чего не делает");
    }
}
