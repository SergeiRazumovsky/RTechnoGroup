public class ArithmeticMeanFrom0to100 {
    public static void main(String[] args) {

        int summ = 0; // сумма чисел
        int count = 1; // количество чисел

        while (count <= 100)
        {
            summ += count;
            count++;
        }
        float result = summ / (float) count; // находим среднюю арифметическую
        System.out.println(result);
    }}