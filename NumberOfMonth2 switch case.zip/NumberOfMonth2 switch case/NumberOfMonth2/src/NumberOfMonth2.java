import java.util.Scanner;

public class NumberOfMonth2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int choice = 0;
        System.out.println("What month of the account do you want to withdraw? \nEnter the number");
        choice = scan.nextInt();
        switch (choice) // Функция проверяет значение, введеное пользователем
        {
            case 1 :  // то же самое, что и if. Если то то, тогда выведи на экран то то
            System.out.println("First month in year - January");
            break;
            case 2 :
            System.out.println("Second month in year - February");
            break;
            case 3 :
            System.out.println("Third month in year - March");
            break;
            case 4 :
            System.out.println("Fourth month in year - April");
            break;
            case 5 :
            System.out.println("Fifth month in year - May");
            break;
            case 6 :
            System.out.println("Sixth month in year - June");
            break;
            case 7 :
            System.out.println("Seventh month in year - July");
            break;
            case 8 :
            System.out.println("The 8th month in year - August");
            break;
            case 9 :
            System.out.println("The ninth month in year - September");
            break;
            case 10 :
            System.out.println("Tenth month in year - October");
            break;
            case 11 :
            System.out.println("The eleventh month in year - November");
            break;
            case 12 :
            System.out.println("Twelfth month in year - December");
            break;
            default :
            System.out.println("Invalid number");
            break;
        }
    }
}
