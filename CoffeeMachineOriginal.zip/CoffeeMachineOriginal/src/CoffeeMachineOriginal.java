import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class CoffeeMachineOriginal {
    public static void main(String[] args) {
        int moneyAmount = 0;
        int moneyAmount2 = 0;
        int cappuccinoPrice = 200;
        int espressoPrice = 150;
        int americanoPrice = 100;
        int waterPrice = 50;
        int choice = 0;
        int choiceOfBeverage = 0;
        String theUserSelects = " ";
        int active = 1;

        Scanner scan = new Scanner(System.in);
        System.out.println("Вас приветствует Кофе-машина!");
        DateFormat format = new SimpleDateFormat("Сейчас HH:mm a dd MMMM y EEEE");
        Date date = new Date();
        System.out.println(format.format(date));
        System.out.println("У нас Вы можете заказать следующие напитки");
        System.out.println("Капучино - стоимость 200 рублей");
        System.out.println("Эспрессо - стоимость 150 рублей");
        System.out.println("Американо - 100 рублей");
        System.out.println("Вода с лимоном - 50 рублей");

        System.out.println("Для заказа напитка пополните Ваш баланс");
        moneyAmount2 = scan.nextInt();
        moneyAmount2 += moneyAmount;
        System.out.println("Ваш баланс " + moneyAmount2 + " рублей");

        while (active==1) {
            if (moneyAmount2 >= 200) {
                System.out.println("Вы можете заказать");
                System.out.println("Капучино - нажмите 1");
                System.out.println("Эспрессо - нажмите 2");
                System.out.println("Американо - нажмите 3");
                System.out.println("Воду с лимоном  - нажмите 4");
                System.out.println("Какой напиток Вы выбираете?");
            } else if (moneyAmount2 >= 150) {
                System.out.println("Вы можете заказать");
                System.out.println("Капучино - недоступно");
                System.out.println("Эспрессо - нажмите 2");
                System.out.println("Американо  - нажмите 3");
                System.out.println("Воду с лимоном  - нажмите 4");
                System.out.println("Какой напиток Вы выбираете?");
            } else if (moneyAmount2 >= 100) {
                System.out.println("Вы можете заказать");
                System.out.println("Капучино - недоступно");
                System.out.println("Эспрессо - недоступно");
                System.out.println("Американо - нажмите 3");
                System.out.println("Воду с лимоном - нажмите 4");
                System.out.println("Какой напиток Вы выбираете?");
            } else if (moneyAmount2 >= 50) {
                System.out.println("Вы можете заказать");
                System.out.println("Капучино - недоступно");
                System.out.println("Эспрессо - недоступно");
                System.out.println("Американо - недоступно");
                System.out.println("Воду с лимоном - нажмите 4");
                System.out.println("Какой напиток Вы выбираете?");
            } else {
                System.out.println("Вы не можете заказать ничего. Пополните баланс до нужной суммы.");
            }

            while (choiceOfBeverage == 0) {
                theUserSelects = scan.next();
                if (theUserSelects.equalsIgnoreCase("1")) {
                    System.out.println("Готовлю Ваш Капучино. Пожалуйста подождите.");
                    System.out.println("Ваш напиток готов! Спасибо за покупку!");
                    System.out.println("Пожалуйста заберите Вашу сдачу " + (moneyAmount2 - 200) + " рублей");
                    active = 0;
                    break;
                } else if (theUserSelects.equalsIgnoreCase("2")) {
                    System.out.println("Готовлю Ваш Эспрессо. Пожалуйста подождите.");
                    System.out.println("Ваш напиток готов! Спасибо за покупку!");
                    System.out.println("Пожалуйста заберите Вашу сдачу " + (moneyAmount2 - 150) + " рублей");
                    active = 0;
                    break;
                } else if (theUserSelects.equalsIgnoreCase("3")) {
                    System.out.println("Готовлю Ваш Американо. Пожалуйста подождите.");
                    System.out.println("Ваш напиток готов! Спасибо за покупку!");
                    System.out.println("Пожалуйста заберите Вашу сдачу " + (moneyAmount2 - 100) + " рублей");
                    active = 0;
                    break;
                } else if (theUserSelects.equalsIgnoreCase("4")) {
                    System.out.println("Готовлю Вашу воду с лимоном. Пожалуйста подождите.");
                    System.out.println("Ваш напиток готов! Спасибо за покупку!");
                    System.out.println("Пожалуйста заберите Вашу сдачу " + (moneyAmount2 - 50) + " рублей");
                    active = 0;
                    break;
                } else {
                    System.out.println("Некорректно! Попробуйте выбрать заново.");
                }
            }
        }
    }
}