public class TranslatingAVariableUP {
    public static void main(String[] args) {
        int days = 1000;
        int theSpeedOfLight = 300000;
        long seconds = days * 24 * 60 * 60;         // Число получается очень большим, по этому используем long
        long distance = theSpeedOfLight * seconds; // Число получается очень большим, по этому используем long
        // В составе этого выражения присутствует переменная типа int, которая преабразуется в тип long
        // Соответственно происходит перевод в более крупную переменную
        System.out.println(distance);
    }
}
