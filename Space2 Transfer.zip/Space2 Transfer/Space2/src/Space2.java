public class Space2 {
    public static void main(String[] args) {
        String name = "Sergey";
        int age = 35;
        String result = "Привет, \"" + name + "\"! \nТебе " + age + " лет."; // \n - это перенос остатка текста на следующую строчку. \"   \" - выделяется то слово, которое мы хотим вывести в ковычках
        System.out.println(result);
    }
}
