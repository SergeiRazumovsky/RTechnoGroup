public class AgeOfPeople {
    public static void main(String[] args)
    {

        int vasyaAge = 10;
        int katyAge = 20;
        int mishaAge = 30;

        int minAge = -1;
        int middleAge = -1;
        int maxAge = -1;

//  ДЛЯ МИНИМАЛЬНОГО ВОЗРАСТА___________________________________________________________________________________________
        if (vasyaAge <= katyAge && vasyaAge <= mishaAge)
        {
            minAge = vasyaAge;
            System.out.println("minAge (Минимальный возраст из представленных) = " + minAge + " лет" + " - возраст Васи");
        }
        if (katyAge <= vasyaAge && katyAge <= mishaAge)
        {
            minAge = katyAge;
            System.out.println("minAge (Минимальный возраст из представленных) = " + minAge + " лет" + " - возраст Кати");
        }
        if (mishaAge <= vasyaAge && mishaAge <= katyAge)
        {
            minAge = mishaAge;
            System.out.println("minAge (Минимальный возраст из представленных) = " + minAge + " лет" + " - возраст Миши");
        }
//  ДЛЯ СРЕДНЕГО ВОЗРАСТА_______________________________________________________________________________________________
        if (vasyaAge > katyAge && vasyaAge < mishaAge)
        {
            middleAge = vasyaAge;
            System.out.println("middleAge (Средний возраст из представленных) = " + middleAge + " лет" + " - возраст Васи");
        }
        if (vasyaAge < katyAge && vasyaAge > mishaAge)
        {
            middleAge = vasyaAge;
            System.out.println("middleAge (Средний возраст из представленных) = " + middleAge + " лет" + " - возраст Васи");
        }
        if (katyAge > vasyaAge && katyAge < mishaAge)
        {
            middleAge = katyAge;
            System.out.println("middleAge (Средний возраст из представленных) = " + middleAge + " лет" + " - возраст Кати");
        }
        if (katyAge < vasyaAge && katyAge > mishaAge)
        {
            middleAge = katyAge;
            System.out.println("middleAge (Средний возраст из представленных) = " + middleAge + " лет" + " - возраст Кати");
        }
        if (mishaAge > vasyaAge && mishaAge < katyAge)
        {
            middleAge = mishaAge;
            System.out.println("middleAge (Средний возраст из представленных) = " + middleAge + " лет" + " - возраст Миши");
        }
        if (mishaAge < vasyaAge && mishaAge > katyAge)
        {
            middleAge = mishaAge;
            System.out.println("middleAge (Средний возраст из представленных) = " + middleAge + " лет" + " - возраст Миши");
        }
//  ДЛЯ МАКСИМАЛЬНОГО ВОЗРАСТА__________________________________________________________________________________________
        if (vasyaAge >= katyAge && vasyaAge >= mishaAge)
        {
            maxAge = vasyaAge;
            System.out.println("maxAge (Максимальный возраст из представленных) = " + maxAge + " лет" + " - возраст Васи");
        }
        if (katyAge >= vasyaAge && katyAge >= mishaAge)
        {
            maxAge = katyAge;
            System.out.println("maxAge (Максимальный возраст из представленных) = " + maxAge + " лет" + " - возраст Кати");
        }
        if (mishaAge >= vasyaAge && mishaAge >= katyAge)
        {
            maxAge = mishaAge;
            System.out.println("maxAge (Максимальный возраст из представленных) = " + maxAge + " лет" + " - возраст Миши");
        }
    }
}

/* ВАРИАНТ РЕШЕНИЯ № 2

            System.out.println("В соответствие с указанными возрастами люди относятся к следующим возростным категориям:");
        if (vasyaAge >= 1 && vasyaAge <= 20)
        {
            System.out.println("Вася относится к категории minAge");
        }
        if (vasyaAge >= 21 && vasyaAge <= 40)
        {
            System.out.println("Вася относится к категории middleAge");
        }
        if (vasyaAge >= 41)
        {
            System.out.println("Вася относится к категории maxAge");
        }
        if (katyAge >= 1 && katyAge <= 20)
        {
            System.out.println("Катя относится к категории minAge");
        }
        if (katyAge >= 21 && katyAge <= 40)
        {
            System.out.println("Катя относится к категории middleAge");
        }
        if (katyAge >= 41)
        {
            System.out.println("Катя относится к категории maxAge");
        }
        if (mishaAge >= 1 && mishaAge <= 20)
        {
            System.out.println("Миша относится к категории minAge");
        }
        if (mishaAge >= 21 && mishaAge <= 40)
        {
            System.out.println("Миша относится к категории middleAge");
        }
        if (mishaAge >= 41)
        {
            System.out.println("Миша относится к категории maxAge");
        }
    }
}
*/
