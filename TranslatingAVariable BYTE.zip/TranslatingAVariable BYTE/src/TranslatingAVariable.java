public class TranslatingAVariable {
    public static void main(String[] args)
    {
        int a = 15;
        byte b = (byte) a; // Переводим переменную в более мелкую переменную
        System.out.println (b);
    }
}
