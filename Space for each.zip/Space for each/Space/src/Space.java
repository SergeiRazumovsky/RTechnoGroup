public class Space {
    public static void main(String[] args) {
        int[] dayOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; // Дней в месяце
        for (int i : dayOfMonth) // При помощи цикла for each
        {
            System.out.println(i); // Выводим массив на экран
        }
    }
}
