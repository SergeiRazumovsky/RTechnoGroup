import java.util.Random;
import java.util.Scanner;

public class doubleArray {

    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scan = new Scanner(System.in);  //Осущетвляет захват информации из консоли
        int counter = 0;
        int temp = 0;
        int mass[][] = new int[10][10];        //Сначала координата у, затем х

// При размещении случайных чисел контролировать, что бы кол-во чисел в строке не превышала какого либо заданного уровня.

        System.out.println("Какое число хотите найти?");
        System.out.println("Число должно быть от 1 до " + mass.length);
        temp = scan.nextInt();
        while (temp < 1 || temp > mass.length) {
            System.out.println("Вы ввели неверное число. Вводимое число должно быть от 1 до 9");
            System.out.println("Введите число заново");
            temp = scan.nextInt();
        }
        if (temp >= 1 || temp <= mass.length) {
            for (int y = 0; y < mass.length; y++) {
                for (int x = 0; x < mass.length; x++) {
                    mass[y][x] = rand.nextInt(9) + 1;
                }
            }
        }
//_________________________________________________________________________________________________________

// В забитом случайными числами (от 1 до 9) массиве (целиком) найти координаты всех чисел, идентичных запрошенному пользователем.

        for (int y = 0; y < mass.length; y++) {
            for (int x = 0; x < mass.length; x++) {
                if (mass[y][x] == temp) {
                    System.out.println("Найдено число " + temp + " по координатам Х:" + x + " Y:" + y);
                }
            }
        }
//_________________________________________________________________________________________________________

// Разместить единицы в массиве по диагонали с правого верхнего до левого нижнего угла

        for (int i = 0; i < mass.length; i++) {  // Единицы по диагонали с лева на право
            mass[i][i] = 1;
        }

        for (int y = 0; y < mass.length; y++) {  // Единицы по диагонали с право на лево
            for (int x = 0; x < mass.length; x++) {
                if (y + x + 1 == mass.length)
                    mass[y][x] = 1;
            }
        }
//_____________________________________________________________________________________

// Подсчитать сумму чисел в каждой строке и вывести эту сумму в коце строки через какой либо символ

        for (int y = 0; y < mass.length; y++) {
            for (int x = 0; x < mass.length; x++) {
                temp += mass[y][x];
                System.out.print(mass[y][x] + " ");
            }
            System.out.print("  ∑ чисел строки" + " = " + temp);
            temp = 0;
            System.out.println(" ");
        }
//______________________________________________________________________________________

    }
}

/*
        System.out.println("Сколько числел хотите разместить?");
        counter= scan.nextInt();

        while(counter>0){
            int x = rand.nextInt(mass.length);
            int y = rand.nextInt(mass.length);
            if (mass[y][x]==0){
                mass[y][x]= rand.nextInt(9)+1;
                counter--;
            }
        }

        for (int y =0;y< mass.length;y++) {   // если нужно, чтобы суммы по строкам выводились под массивом
        for (int x = 0; x < mass.length; x++) {
            temp += mass[y][x];
            }
            System.out.println("Сумма чисел в строке №" + (y+1) + " ровняется " + temp);
            temp=0;
*/

// ДЗ
// Разместить единицы в массиве по диагонали с правого верхнего до левого нижнего угла
// Подсчитать сумму чисел в каждой строке и вывести эту сумму в коце строки через какой либо символ
// При размещении случайных чисел контролировать, что бы кол-во чисел в строке не превышала какого либо заданного уровня.
// В забитом случайными числами (от 1 до 9) массиве (целиком) найти координаты всех чисел, идентичных запрошенному пользователем.
