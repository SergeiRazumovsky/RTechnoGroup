public class Char {
    public static void main(String[] args) {
        char ch1 = 88;
        ch1 += 1; // Мы прибавили 1 и получаем уже переменную Y, а не X
        char ch2 = 'X'; // По таблице ASCII X = 88 // Ставим Одинарные ковычки
        System.out.println("ch1 - " + ch1 + " ch2 - " + ch2);
    }
}
