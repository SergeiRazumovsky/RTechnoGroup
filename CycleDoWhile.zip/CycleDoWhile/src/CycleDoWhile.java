import com.sun.source.tree.WhileLoopTree;

public class CycleDoWhile {
    public static void main(String[] args) {
        int a = 0;
        do  // цикл do (то, что находится у него в фигурных скобках) выполняется вне зависимости выполняется условие while или нет
        {
            System.out.println("Привет Мир!");
        }
        while (a > 0);
    }
}
