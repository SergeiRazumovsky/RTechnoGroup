import java.util.Random;
import java.util.Scanner;

public class NewArray {
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scan = new Scanner(System.in);  // осущетвляет захват информации из консоли
        int[] mass = new int[25];
        int theStartOfTheRange = 0;
        int theEndOfTheRange = 0;
        int temp = 0;
        int cellNumber = 0;
        int inputNumber = 0;
        int userResponceNumber = 0;
        int userSelection = 0;
        String userResponse = " ";
        String userResponse1 = " ";
        // for - это цикл, призванный сделать определенное кол-во отсчетов с определенным интервалом до определенного места.
        // 3 аргумента, разделяемые ;
        // 1) Переменная - счётчик, которая непостредственно считает с оперделенным шагом и значения которой обычно и важны. Тут мы её создаём и задаём стартовое значение.
        // 2) Условие, до которого мы будем считать. Т.е. пока условие выполняется, мы продолжаем считать.
        // 3) Модификатор счёта. То, по сколько мы будем считать. Выражение, которое будет применятся к переменной - счетчику в конце выполнения команд внутри фигурных скобок

        for (int i = 0; i < mass.length; i++)
        {
            mass[i] = rand.nextInt(5) + 5;
        }


            System.out.println("В какую ячейку Вы хотите записать число?");
            temp = scan.nextInt();
            if (temp > 0 && temp <= mass.length) // && - логическое И. if сработает только при выполнении обоих условий
            {
            }
            else
            {
            System.out.println("У нас диапазон от 1 до " + mass.length + ", попробуйте снова");
            }
            System.out.println("Введите само число: ");
            mass[temp - 1] = scan.nextInt(); //подводный камень
            for (int i = 0; i < mass.length; i++)
            {
            System.out.print(mass[i] + " ");
            }
            System.out.println(" ");
            temp = 0;
            for (int i = 0; i < mass.length; i++)
            {
            temp += mass[i];
            }

        while (true)
        {
            System.out.println("Какую операцию выполнить дальше?");
            System.out.println("Вывести сумму всех элементов массива - Нажмите цифру 1");
            System.out.println("Вывести произведение всех элементов массива - Нажмите цифру 2");
            System.out.println("Изменить содержимое какой либо из ячеек исходного массива - Нажмите цифру 3");
            System.out.println("Вывести сокращенный диапозон массива - Нажмите цифру 4");
            System.out.println("Вновь вывести на экран весь заданый массив - Нажмите цифру 5");
            System.out.println("Добавить числа в случайные ячейки массива - Нажмите цифру 6");
            System.out.println("Ничего болшьше не требуется - Нажмите цифру 7");
            userSelection = scan.nextInt();

            if (userSelection == 1)
            {

                for (int i = 0; i < mass.length; i++)
                {
                temp += mass[i];
                }
                System.out.println("Сумма ячеек массива равна " + temp);
            }

            if (userSelection == 2)
            {
                for (int i = 0; i < mass.length; i++)
                {
                temp *= mass[i];
                }
                System.out.println("Произведение ячеек массива равно " + temp);
            }

            if (userSelection == 3) {
                System.out.println("Ведите номер ячейки");
                cellNumber = scan.nextInt();
                while (cellNumber <= 0 || cellNumber > mass.length)
                {
                    System.out.println("Вы ввели некорректный номер ячейки. Массив содержит " + mass.length + " ячеек. Попробуйте снова.");
                    System.out.println("Ведите номер ячейки");
                    cellNumber = scan.nextInt();
                }
                if (cellNumber <= mass.length)
                {
                System.out.println("Ведите число, на которое желаете изменить текущее значение ячейки");
                }
                mass[cellNumber - 1] = scan.nextInt();
                for (int i = 0; i < mass.length; i++)
                {
                System.out.print(mass[i] + " ");
                }
                System.out.println(" ");

            }

                if (userSelection == 4) {
                    System.out.println("Введите число, c которого будут генерироваться числа внутри массива");
                    int temp2 = scan.nextInt();
                    System.out.println("Введите число, до которого будут генерироваться числа внутри массива");
                    temp = scan.nextInt() + 1;
                    for (int i = 0; i < mass.length; i++) {
                        mass[i] = rand.nextInt(temp - temp2) + temp2;
                    }

                    /*
                    for (int i=0;i<mass.length;i++)        // Активировать эту часть кода в случае, если не требуется выводить конкретный диапозон
                    {
                    System.out.print(mass[i] + " ");
                    }
                     System.out.println(" ");
                    */

                    System.out.println("Введите диапозон для вывода элементов из массива");
                    System.out.println("Напоминаем, что выбранный Вами размер массива составляет " + mass.length + " элементов");
                    System.out.println("Введите номер начального элемента диапозона");
                    theStartOfTheRange = scan.nextInt() - 1;

                    while (theStartOfTheRange < 0 || theStartOfTheRange > mass.length) {
                        System.out.println("Вы ввели некорректный номер начального элемента диапозона. Попробуйте снова.");
                        theStartOfTheRange = scan.nextInt() - 1;
                    }
                        System.out.println("Введите номер конечного элемента диапозона");
                        theEndOfTheRange = scan.nextInt();
                    while (theEndOfTheRange < theStartOfTheRange || theEndOfTheRange > mass.length) {
                        System.out.println("Вы ввели некорректный номер конечного элемента диапозона. Попробуйте снова.");
                        theEndOfTheRange = scan.nextInt() - 1;
                    }

                        for (int i = theStartOfTheRange; i < theEndOfTheRange; i++) {
                            System.out.print(mass[i] + " ");
                        }
                        System.out.println(" ");
                }

                if (userSelection == 5)
                   {
                   for (int i = 0; i < mass.length; i++)
                   {
                   System.out.print(mass[i]+" ");
                   }
                   System.out.println(" ");
                   }

                if (userSelection == 6)
                {
            /*
            System.out.println("Какое число вы хотите вводить в массив? ");
            int num = scan.nextInt();          //То число, копии которого будут в массиве
            System.out.println("сколько таких чисел должно быть в массиве?");
            int counter = scan.nextInt();     //Сколько таких дублей числа num будет в массиве

            while(counter!=0){                //пытаемся разместить число в массив, пока не разместим нужное кол-во
            temp=rand.nextInt(mass.length);   //отвечает за обращение к случайной ячейке в массиве (генерирует случайный номер)
            if(mass[temp]!=num){              //если по текущему случайному адресу не находится размещаемое число,
            mass[temp]=num;                   //то мы его туда ставим
            counter--;                        //уменьшаем кол-во оставшихся для размещения чисел
            }
            }
             */
                    System.out.println("Сколько чисел вы хотите вводить в массив? ");
                    int counter = scan.nextInt();   //отвечает за разнообразие вводимых цифр
                    int mastemp[] = new int[100];
                    for(int i =0;i<counter;i++)
                    {
                    System.out.println("введите очередное число");
                    mastemp[i]=scan.nextInt();
                    }
                    while(counter>=0)
                    {                      //пытаемся разместить числа в массив, пока не разместим нужное кол-во
                    temp=rand.nextInt(mass.length);     //отвечает за обращение к случайной ячейке в массиве (генерирует случайный номер)
                    if(mass[temp]!=mastemp[counter])   //если по текущему случайному адресу не находится текущее размещаемое число из массива
                    {
                    mass[temp]=mastemp[counter];    //то мы его туда ставим
                    counter--;                      //уменьшаем кол-во оставшихся для размещения чисел
                    }
                    }
                    for (int i = 0; i < mass.length; i++)
                    {
                    System.out.print(mass[i]+" ");
                    }
                    System.out.println(" ");
                }

                if (userSelection == 7)
                {
                    System.out.println("Хорошо. Буду ждать Вашу следующую команду.");
                }
        }
    }
}

//Для вставки указанного кол-ва указанных чисел в случайные уникальные ячейки массива.

//ДЗ
// п.3 - ввести проверку вводимой ячейки на её наличие в массиве
// п.4 - ввести проверку на корректность ввода диапазона для вывода чисел